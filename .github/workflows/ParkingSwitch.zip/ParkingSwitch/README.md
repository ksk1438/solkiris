# 주차 스위치 · Android 소스 프로젝트

원하는 지하층을 등록하고 홈 화면 위젯에서 조명 스위치처럼 선택하는 앱입니다.

## 동작
- 기본 B1–B4, 원하는 양의 정수 지하층 추가 및 삭제, 숫자순 정렬.
- 버튼을 누르면 해당 층 ON. 다른 층은 OFF. 같은 층을 다시 누르면 전체 OFF.
- 선택한 층 삭제 시 주차 표시 해제. 중복 층 입력 방지.
- 위젯은 6개 층씩 표시하며 이전/다음 페이지 지원. 현재 주차 층은 상단에 항상 표시.
- 앱과 모든 위젯이 동일한 주차 위치 공유. 페이지는 위젯별 저장.
- 기기 내 저장. 인터넷 및 위치 권한 없이 사용. GPS 자동 층 감지는 포함하지 않음.

## 빌드 및 설치
이 ZIP은 소스 코드이며 설치용 APK가 아닙니다. 이 환경에는 Android SDK/Gradle이 없어 Android 빌드 및 실기기 검증은 수행하지 못했습니다.

1. PC에 Android Studio, JDK 17, Android SDK Platform 35를 설치합니다.
2. ZIP을 해제하고 ParkingSwitch 폴더를 Android Studio에서 엽니다.
3. 이 프로젝트는 AGP 8.7.3 / Gradle 8.9를 사용합니다. Gradle wrapper 바이너리는 포함하지 않았습니다. Gradle 8.9를 설치한 후 프로젝트 폴더에서 `gradle wrapper --gradle-version 8.9`를 실행하거나 Android Studio에서 로컬 Gradle 8.9를 지정합니다.
4. Gradle Sync 후 USB 디버깅을 켠 Android 기기를 연결하고 Run을 실행합니다.
5. 또는 `./gradlew assembleDebug`로 생성한 `app/build/outputs/apk/debug/app-debug.apk`를 기기에 설치합니다.
6. 앱에서 층을 설정한 다음 ‘홈 화면에 위젯 추가’를 누릅니다. 지원되지 않으면 홈 화면 빈 곳 길게 누르기 → 위젯 → 주차 스위치.

Android 8.0 이상. 스토어 배포용 서명은 별도로 필요합니다.

## 검증 상태
Java 순수 상태 로직 테스트와 XML 파싱 검사 완료. Android 컴파일, APK 설치, 실제 위젯 표시/터치 및 재부팅 복원은 미검증입니다.

## 기기에서 확인할 항목
1. 위젯에서 B2 누르기 → B2만 ON → B3 누르기 → B2 OFF/B3 ON → B3 다시 누르기 → 모두 OFF.
2. 앱 종료 및 휴대전화 재부팅 후 선택 유지.
3. B10 추가 및 중복 방지, 선택한 층 삭제 후 주차 표시 해제.
4. 7개 이상 층 등록 후 페이지 이동, 마지막 페이지의 층 삭제 후 범위 보정.
5. 위젯 2개 배치 후 서로 선택 동기화, 크기 변경 및 폴드 외부/내부 화면에서 가독성.

## 구조
- MainActivity.java: 층 관리와 위젯 추가
- ParkingState.java: 선택/정렬/페이지 규칙
- ParkingStore.java: 로컬 저장과 위젯 갱신
- ParkingWidget.java: 홈 화면 버튼 및 상태 표시
- res/layout/widget.xml: 위젯 레이아웃

위젯 구현 참고: https://developer.android.com/develop/ui/views/appwidgets

## 상태 규칙 테스트 재실행
JDK 17에서 프로젝트 루트 기준:
```sh
mkdir -p /tmp/parking-tests
javac -d /tmp/parking-tests app/src/main/java/kr/solki/parkingswitch/ParkingState.java tests/StateCheck.java
java -cp /tmp/parking-tests StateCheck
```
