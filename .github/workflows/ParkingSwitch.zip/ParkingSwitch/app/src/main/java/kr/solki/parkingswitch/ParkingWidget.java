package kr.solki.parkingswitch;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import java.util.*;
public class ParkingWidget extends AppWidgetProvider {
 private static final String ACTION="kr.solki.parkingswitch.CONTROL";
 static final int[] IDS={R.id.floor0,R.id.floor1,R.id.floor2,R.id.floor3,R.id.floor4,R.id.floor5};
 static void refresh(Context c) {
  AppWidgetManager m=AppWidgetManager.getInstance(c);
  for(int id:m.getAppWidgetIds(new ComponentName(c,ParkingWidget.class))) render(c,m,id);
 }
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids) { for(int id:ids) render(c,m,id); }
 @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle b) { render(c,m,id); }
 @Override public void onDeleted(Context c,int[] ids) { for(int id:ids) ParkingStore.prefs(c).edit().remove("page"+id).apply(); }
 @Override public void onReceive(Context c,Intent intent) {
  super.onReceive(c,intent);
  if(!ACTION.equals(intent.getAction())) return;
  int id=intent.getIntExtra("widget",-1);
  int[] active=AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,ParkingWidget.class));
  boolean found=false; for(int x:active) if(x==id) found=true; if(!found) return;
  String op=intent.getStringExtra("op"); int value=intent.getIntExtra("value",0);
  if("floor".equals(op)) ParkingStore.toggle(c,value);
  else if("page".equals(op)) {
   int page=ParkingState.page(ParkingStore.prefs(c).getInt("page"+id,0),ParkingStore.floors(c).size());
   ParkingStore.prefs(c).edit().putInt("page"+id,ParkingState.page(page+value,ParkingStore.floors(c).size())).commit();
   render(c,AppWidgetManager.getInstance(c),id);
  }
 }
 static PendingIntent action(Context c,int id,String op,int value) {
  Intent i=new Intent(c,ParkingWidget.class).setAction(ACTION).setData(Uri.parse("parkingswitch://widget/"+id+"/"+op+"/"+value));
  i.putExtra("widget",id).putExtra("op",op).putExtra("value",value);
  return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 static void render(Context c,AppWidgetManager m,int id) {
  List<Integer> fs=ParkingStore.floors(c); int selected=ParkingStore.selected(c);
  int page=ParkingState.page(ParkingStore.prefs(c).getInt("page"+id,0),fs.size());
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
  v.setTextViewText(R.id.status,selected==0?"주차 위치를 선택하세요":"● 지하 "+selected+"층에 주차 중");
  for(int i=0;i<6;i++) {
   int index=page*6+i; boolean visible=index<fs.size();
   v.setViewVisibility(IDS[i],visible?View.VISIBLE:View.INVISIBLE); if(!visible) continue;
   int f=fs.get(index); boolean on=f==selected;
   v.setTextViewText(IDS[i],"B"+f+"\n"+(on?"● ON":"○ OFF"));
   v.setTextColor(IDS[i],android.graphics.Color.parseColor(on?"#073D30":"#C7D3E1"));
   v.setInt(IDS[i],"setBackgroundResource",on?R.drawable.on:R.drawable.off);
   v.setContentDescription(IDS[i],"지하 "+f+"층, "+(on?"주차 중. 누르면 해제":"선택하려면 누르세요"));
   v.setOnClickPendingIntent(IDS[i],action(c,id,"floor",f));
  }
  v.setTextViewText(R.id.page,fs.isEmpty()?"설정에서 층 추가":(page+1)+" / "+Math.max(1,(fs.size()+5)/6));
  v.setViewVisibility(R.id.previous,page>0?View.VISIBLE:View.INVISIBLE);
  v.setViewVisibility(R.id.next,(page+1)*6<fs.size()?View.VISIBLE:View.INVISIBLE);
  v.setOnClickPendingIntent(R.id.previous,action(c,id,"page",-1));
  v.setOnClickPendingIntent(R.id.next,action(c,id,"page",1));
  v.setOnClickPendingIntent(R.id.settings,PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
  m.updateAppWidget(id,v);
 }
}
