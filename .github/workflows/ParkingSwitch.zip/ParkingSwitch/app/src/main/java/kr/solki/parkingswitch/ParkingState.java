package kr.solki.parkingswitch;
import java.util.*;
/** Pure state rules; 0 means no parking selection. */
public final class ParkingState {
 public static List<Integer> parse(String raw) {
  TreeSet<Integer> out=new TreeSet<>();
  for(String s:raw.split(",")) try { int f=Integer.parseInt(s); if(f>0) out.add(f); } catch(NumberFormatException ignored) {}
  return new ArrayList<>(out);
 }
 public static int toggle(int selected,int pressed) { return selected==pressed?0:pressed; }
 public static String encode(List<Integer> floors) { StringJoiner j=new StringJoiner(","); for(int f:floors) j.add(""+f); return j.toString(); }
 public static int page(int requested,int count) { return Math.max(0,Math.min(requested,Math.max(0,(count-1)/6))); }
}
