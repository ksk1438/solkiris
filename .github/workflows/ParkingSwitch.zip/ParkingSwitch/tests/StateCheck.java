import java.util.*;
import kr.solki.parkingswitch.ParkingState;
class StateCheck {
 public static void main(String[] args) {
  check(ParkingState.toggle(0,2)==2); check(ParkingState.toggle(2,3)==3); check(ParkingState.toggle(3,3)==0);
  check(ParkingState.parse("4,2,2,-1,abc,10").equals(Arrays.asList(2,4,10)));
  check(ParkingState.page(5,7)==1); check(ParkingState.page(1,6)==0); check(ParkingState.page(-1,0)==0);
  check(ParkingState.parse(ParkingState.encode(Arrays.asList(1,3,8))).equals(Arrays.asList(1,3,8)));
  System.out.println("8 state checks passed");
 }
 static void check(boolean ok) { if(!ok) throw new AssertionError(); }
}


/** Pure state rules; 0 means no parking selection. */
