import java.util.*;
import kr.solki.parkingswitch.ParkingState;
class StateCheck {
 public static void main(String[] args) {
  check(ParkingState.toggle(0,2)==2); check(ParkingState.toggle(2,3)==3); check(ParkingState.toggle(3,3)==0);
  check(ParkingState.parse("4,2,2,-1,abc,10").equals(Arrays.asList(2,4,10)));
  check(ParkingState.page(5,7)==1); check(ParkingState.page(1,6)==0); check(ParkingState.page(-1,0)==0);
  check(ParkingState.parse(ParkingState.encode(Arrays.asList(1,3,8))).equals(Arrays.asList(1,3,8)));
  for(int capacity:new int[]{4,6}) for(int count=0;count<30;count++) for(int requested=-2;requested<40;requested++) {
   int start=ParkingState.offset(requested,count,capacity);
   check(start>=0); check(start%capacity==0); check(count==0?start==0:start<count);
   if(start+capacity<count) check(ParkingState.offset(start+capacity,count,capacity)==start+capacity);
  }
  check(ParkingState.offset(8,5,4)==4);
  check(ParkingState.offset(4,12,6)==0);
  System.out.println("State and compact/expanded pagination checks passed");
 }
 static void check(boolean ok) { if(!ok) throw new AssertionError(); }
}


/** Pure state rules; 0 means no parking selection. */
