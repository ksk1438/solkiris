package kr.solki.parkingswitch;
import android.content.*;
import java.util.*;
final class ParkingStore {
 static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("parking",Context.MODE_PRIVATE); }
 static List<Integer> floors(Context c) { return ParkingState.parse(prefs(c).getString("floors","1,2,3,4")); }
 static int selected(Context c) { return prefs(c).getInt("selected",0); }
 static void toggle(Context c,int f) {
  if(!floors(c).contains(f)) return;
  prefs(c).edit().putInt("selected",ParkingState.toggle(selected(c),f)).commit();
  ParkingWidget.refresh(c);
 }
 static void save(Context c,List<Integer> floors) {
  Collections.sort(floors);
  android.content.SharedPreferences.Editor e=prefs(c).edit().putString("floors",ParkingState.encode(floors));
  if(!floors.contains(selected(c))) e.putInt("selected",0);
  e.commit(); ParkingWidget.refresh(c);
 }
}
