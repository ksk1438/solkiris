package kr.solki.parkingswitch;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import java.util.*;
public class ParkingWidget extends AppWidgetProvider {
 private static final String ACTION="kr.solki.parkingswitch.CONTROL";
 static final int[] IDS={R.id.floor0,R.id.floor1,R.id.floor2,R.id.floor3,R.id.floor4,R.id.floor5};
 static void refresh(Context c) {
  AppWidgetManager m=AppWidgetManager.getInstance(c);
  for(int id:m.getAppWidgetIds(new ComponentName(c,ParkingWidget.class))) render(c,m,id);
 }
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids) { for(int id:ids) render(c,m,id); }
 @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle b) { render(c,m,id); }
 @Override public void onDeleted(Context c,int[] ids) { for(int id:ids) ParkingStore.prefs(c).edit().remove("offset"+id).remove("page"+id).apply(); }
 @Override public void onReceive(Context c,Intent intent) {
  super.onReceive(c,intent);
  if(!ACTION.equals(intent.getAction())) return;
  int id=intent.getIntExtra("widget",-1);
  int[] active=AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,ParkingWidget.class));
  boolean found=false; for(int x:active) if(x==id) found=true; if(!found) return;
  String op=intent.getStringExtra("op"); int value=intent.getIntExtra("value",0);
  if("floor".equals(op)) ParkingStore.toggle(c,value);
  else if("page".equals(op)) {
   ParkingStore.prefs(c).edit().putInt("offset"+id,Math.max(0,value)).commit();
   render(c,AppWidgetManager.getInstance(c),id);
  }
 }
 static PendingIntent action(Context c,int id,String op,int value) {
  Intent i=new Intent(c,ParkingWidget.class).setAction(ACTION).setData(Uri.parse("parkingswitch://widget/"+id+"/"+op+"/"+value));
  i.putExtra("widget",id).putExtra("op",op).putExtra("value",value);
  return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 static void render(Context c,AppWidgetManager m,int id) {
  if(android.os.Build.VERSION.SDK_INT>=31) {
   Map<android.util.SizeF,RemoteViews> layouts=new LinkedHashMap<>();
   layouts.put(new android.util.SizeF(250,48),views(c,id,true));
   layouts.put(new android.util.SizeF(250,160),views(c,id,false));
   m.updateAppWidget(id,new RemoteViews(layouts));
  } else {
   Bundle options=m.getAppWidgetOptions(id);
   boolean landscape=c.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
   int height=options.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT:AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,48);
   m.updateAppWidget(id,views(c,id,height<160));
  }
 }
 static RemoteViews views(Context c,int id,boolean compact) {
  List<Integer> fs=ParkingStore.floors(c); int selected=ParkingStore.selected(c);
  int capacity=compact?4:6;
  int offset=ParkingState.offset(ParkingStore.prefs(c).getInt("offset"+id,0),fs.size(),capacity);
  int page=offset/capacity;
  RemoteViews v=new RemoteViews(c.getPackageName(),compact?R.layout.widget_compact:R.layout.widget);
  v.setTextViewText(R.id.status,selected==0?(fs.isEmpty()?"설정에서 층을 추가하세요":"주차 위치를 선택하세요"):"● 지하 "+selected+"층에 주차 중");
  for(int i=0;i<capacity;i++) {
   int index=offset+i; boolean visible=index<fs.size();
   v.setViewVisibility(IDS[i],visible?View.VISIBLE:View.INVISIBLE); if(!visible) continue;
   int f=fs.get(index); boolean on=f==selected;
   v.setTextViewText(IDS[i],compact?(on?"● ":"○ ")+"B"+f:"B"+f+"\n"+(on?"● ON":"○ OFF"));
   v.setTextColor(IDS[i],android.graphics.Color.parseColor(on?"#073D30":"#C7D3E1"));
   v.setInt(IDS[i],"setBackgroundResource",on?R.drawable.on:R.drawable.off);
   v.setContentDescription(IDS[i],"지하 "+f+"층, "+(on?"주차 중. 누르면 해제":"선택하려면 누르세요"));
   v.setOnClickPendingIntent(IDS[i],action(c,id,"floor",f));
  }
  int pages=Math.max(1,(fs.size()+capacity-1)/capacity);
  v.setTextViewText(R.id.page,fs.isEmpty()?"설정에서 층 추가":(page+1)+" / "+pages);
  v.setViewVisibility(R.id.previous,page>0?View.VISIBLE:View.GONE);
  v.setViewVisibility(R.id.next,offset+capacity<fs.size()?View.VISIBLE:View.GONE);
  v.setOnClickPendingIntent(R.id.previous,action(c,id,"page",Math.max(0,offset-capacity)));
  v.setOnClickPendingIntent(R.id.next,action(c,id,"page",offset+capacity));
  v.setOnClickPendingIntent(R.id.settings,PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
  return v;
 }
}
