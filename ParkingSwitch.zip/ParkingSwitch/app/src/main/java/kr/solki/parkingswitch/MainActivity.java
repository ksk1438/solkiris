package kr.solki.parkingswitch;
import android.app.*;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
 LinearLayout body;
 @Override public void onCreate(Bundle b) { super.onCreate(b); }
 @Override public void onResume() { super.onResume(); draw(); }
 int dp(int n) { return (int)(getResources().getDisplayMetrics().density*n+.5f); }
 TextView label(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(16,28,41)); t.setPadding(0,dp(8),0,dp(8)); return t; }
 Button button(String s) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
 void draw() {
  ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
  body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(24),dp(24),dp(24),dp(24)); scroll.addView(body); setContentView(scroll);
  if(android.os.Build.VERSION.SDK_INT>=30) scroll.setOnApplyWindowInsetsListener((v,insets)-> { android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()); v.setPadding(bars.left,bars.top,bars.right,bars.bottom); return insets; });
  // The modern insets API is available from Android 11; older versions use decor fitting.
  if(android.os.Build.VERSION.SDK_INT<30) scroll.setOnApplyWindowInsetsListener(null);
  body.addView(label("주차 스위치",30));
  int selected=ParkingStore.selected(this);
  body.addView(label(selected==0?"어디에 주차하셨나요?":"● 지하 "+selected+"층에 주차 중",22));
  body.addView(label("층 버튼을 누르면 ON, 다시 누르면 OFF.\n다른 층을 누르면 주차 위치가 바뀝니다.",15));
  for(int f:ParkingStore.floors(this)) {
   LinearLayout row=new LinearLayout(this);
   Button floor=button("B"+f+"  ·  "+(selected==f?"● ON":"○ OFF"));
   floor.setTextColor(Color.parseColor(selected==f?"#087F67":"#34485D"));
   row.addView(floor,new LinearLayout.LayoutParams(0,dp(60),1));
   floor.setOnClickListener(v->{ParkingStore.toggle(this,f);draw();});
   Button remove=button("삭제"); row.addView(remove,new LinearLayout.LayoutParams(dp(76),dp(60)));
   remove.setContentDescription("지하 "+f+"층 삭제");
   remove.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("지하 "+f+"층을 삭제할까요?"+(ParkingStore.selected(this)==f?" 주차 표시도 해제됩니다.":""))
    .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->{List<Integer> fs=ParkingStore.floors(this);fs.remove(Integer.valueOf(f));ParkingStore.save(this,fs);draw();}).show());
   body.addView(row);
  }
  Button add=button("＋ 지하층 추가"); body.addView(add); add.setOnClickListener(v->addFloor());
  Button pin=button("홈 화면에 위젯 추가"); body.addView(pin);
  pin.setOnClickListener(v->{AppWidgetManager m=AppWidgetManager.getInstance(this);if(m.isRequestPinAppWidgetSupported())m.requestPinAppWidget(new ComponentName(this,ParkingWidget.class),null,null);else new AlertDialog.Builder(this).setMessage("홈 화면 빈 곳을 길게 누른 뒤 위젯 → 주차 스위치를 선택하세요.").setPositiveButton("확인",null).show();});
  body.addView(label("작은 위젯은 한 줄에 4개, 큰 위젯은 두 줄에 6개 층이 표시됩니다. 층이 많으면 ‹ ›로 넘겨보세요.\n모든 위젯은 같은 주차 위치를 표시합니다.\n선택은 휴대전화에 저장됩니다.",14));
 }
 void addFloor() {
  EditText input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_NUMBER);input.setHint("예: 5 → 지하 5층");input.setSingleLine(true);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("추가할 지하층 숫자").setView(input).setNegativeButton("취소",null).setPositiveButton("추가",null).create();
  dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
   int f;try {f=Integer.parseInt(input.getText().toString().trim());if(f<=0)throw new NumberFormatException();}catch(NumberFormatException e){input.setError("1 이상의 숫자를 입력하세요");return;}
   List<Integer> fs=ParkingStore.floors(this);if(fs.contains(f)){input.setError("이미 추가한 층이에요");return;}
   fs.add(f);ParkingStore.save(this,fs);dialog.dismiss();draw();
  }));dialog.show();
 }
}
