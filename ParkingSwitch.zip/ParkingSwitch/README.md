# 주차 스위치 · Android 소스 프로젝트

원하는 지하층을 등록하고 홈 화면 위젯에서 조명 스위치처럼 선택하는 앱입니다.

## 동작
- 기본 B1–B4, 원하는 양의 정수 지하층 추가 및 삭제, 숫자순 정렬.
- 버튼을 누르면 해당 층 ON. 다른 층은 OFF. 같은 층을 다시 누르면 전체 OFF.
- 선택한 층 삭제 시 주차 표시 해제. 중복 층 입력 방지.
- 위젯은 기본 4×1 크기에서 4개 층씩, 높이를 늘리면 6개 층씩 표시하며 이전/다음 페이지 지원. 현재 주차 층은 상단에 항상 표시.
- 앱과 모든 위젯이 동일한 주차 위치 공유. 페이지는 위젯별 저장.
- 기기 내 저장. 인터넷 및 위치 권한 없이 사용. GPS 자동 층 감지는 포함하지 않음.

## 빌드 및 설치
이 ZIP은 소스 코드이며 설치용 APK가 아닙니다. 이 환경에는 Android SDK/Gradle이 없습니다. 0.1.0은 사용자 GitHub Actions에서 빌드 성공했으며, 이번 0.2.0은 Android 빌드 및 실기기 검증 전입니다.

1. PC에 Android Studio, JDK 17, Android SDK Platform 35를 설치합니다.
2. ZIP을 해제하고 ParkingSwitch 폴더를 Android Studio에서 엽니다.
3. 이 프로젝트는 AGP 8.7.3 / Gradle 8.9를 사용합니다. Gradle wrapper 바이너리는 포함하지 않았습니다. Gradle 8.9를 설치한 후 프로젝트 폴더에서 `gradle wrapper --gradle-version 8.9`를 실행하거나 Android Studio에서 로컬 Gradle 8.9를 지정합니다.
4. Gradle Sync 후 USB 디버깅을 켠 Android 기기를 연결하고 Run을 실행합니다.
5. 또는 `./gradlew assembleDebug`로 생성한 `app/build/outputs/apk/debug/app-debug.apk`를 기기에 설치합니다.
6. 앱에서 층을 설정한 다음 ‘홈 화면에 위젯 추가’를 누릅니다. 지원되지 않으면 홈 화면 빈 곳 길게 누르기 → 위젯 → 주차 스위치.

Android 8.0 이상. 스토어 배포용 서명은 별도로 필요합니다.

## 검증 상태
Java 순수 상태 로직 테스트와 XML 파싱 검사 완료. Android 컴파일, APK 설치, 실제 위젯 표시/터치 및 재부팅 복원은 미검증입니다.

## 기기에서 확인할 항목
1. 위젯에서 B2 누르기 → B2만 ON → B3 누르기 → B2 OFF/B3 ON → B3 다시 누르기 → 모두 OFF.
2. 앱 종료 및 휴대전화 재부팅 후 선택 유지.
3. B10 추가 및 중복 방지, 선택한 층 삭제 후 주차 표시 해제.
4. 7개 이상 층 등록 후 페이지 이동, 마지막 페이지의 층 삭제 후 범위 보정.
5. 위젯 2개 배치 후 서로 선택 동기화, 크기 변경 및 폴드 외부/내부 화면에서 가독성.

## 구조
- MainActivity.java: 층 관리와 위젯 추가
- ParkingState.java: 선택/정렬/페이지 규칙
- ParkingStore.java: 로컬 저장과 위젯 갱신
- ParkingWidget.java: 홈 화면 버튼 및 상태 표시
- res/layout/widget.xml: 위젯 레이아웃

위젯 구현 참고: https://developer.android.com/develop/ui/views/appwidgets

## 상태 규칙 테스트 재실행
JDK 17에서 프로젝트 루트 기준:
```sh
mkdir -p /tmp/parking-tests
javac -d /tmp/parking-tests app/src/main/java/kr/solki/parkingswitch/ParkingState.java tests/StateCheck.java
java -cp /tmp/parking-tests StateCheck
```

## 0.2.0 · 4×1 위젯
- 기본/최소 높이를 48dp, 기본 셀 크기를 4×1로 변경.
- 4개 층을 한 줄로 표시하고 큰 높이(160dp 이상)에서 기존 6개 층 레이아웃 사용.
- Android 12 이상에서 크기별 RemoteViews 사용. 폴드 화면 전환에도 런처가 맞는 레이아웃 선택.
- 이전/다음 페이지, 설정, 현재 주차 층 표시 유지. 작은 크기에서는 ●/○와 색으로 ON/OFF 구분.
- 실제 셀 크기는 런처 홈 화면 격자/여백에 따라 달라질 수 있음.

### GitHub에서 업데이트
기존 ParkingSwitch.zip을 이 ZIP으로 교체(이름 유지), Commit changes 후 Actions → Build Parking APK → Run workflow로 새 실행. 기존 main.yml 그대로 사용.
새 APK 설치 후 위젯을 길게 눌러 줄이거나, 기존 위젯만 제거하고 새로 추가.
새 GitHub 러너가 다른 디버그 서명키를 만들면 기존 앱과 서명 충돌로 업데이트 설치가 거부될 수 있음. 그 경우 기존 앱을 삭제하고 재설치해야 하며 등록 층/주차 선택은 초기화됨.

### 이번 변경 확인
4×1 추가, 4×3으로 확대/축소, 내부/외부 화면 전환, 5개 이상 층 등록 후 페이지 전환, 마지막 페이지에서 층 삭제, 위젯 여러 개 동기화 확인 필요.
